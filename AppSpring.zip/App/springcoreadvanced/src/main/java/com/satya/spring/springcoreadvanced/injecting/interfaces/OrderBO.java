package com.satya.spring.springcoreadvanced.injecting.interfaces;

public interface OrderBO {
	 void placeOrder();
}
