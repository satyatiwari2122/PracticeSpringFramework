package com.satya.spring.springcoreadvanced.injecting.interfaces;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new ClassPathXmlApplicationContext("com/satya/spring/springcoreadvanced/injecting/interfaces/config.xml");
		 OrderBO bo =(OrderBOImpl)context.getBean("bo");
		 bo.placeOrder();
	}

}
