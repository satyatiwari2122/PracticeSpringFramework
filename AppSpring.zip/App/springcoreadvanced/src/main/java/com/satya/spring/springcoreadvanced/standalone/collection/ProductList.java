package com.satya.spring.springcoreadvanced.standalone.collection;

import java.util.List;

public class ProductList {
	private List productName;

	@Override
	public String toString() {
		return "ProductList [productName=" + productName + "]";
	}

	public List getProductName() {
		return productName;
	}

	public void setProductName(List productName) {
		this.productName = productName;
	}

}
