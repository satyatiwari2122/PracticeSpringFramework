package com.satya.beans;

public class WelcomeBean {
	
	public String getWelcomeMessage() {
		return "Hello User ! Welcome to Delhi";
	}

}
