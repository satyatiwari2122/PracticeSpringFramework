package com.satya.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.satya.beans.HelloBean;
import com.satya.beans.WelcomeBean;

@Configuration
public class AppConfig {
	@Bean
	public WelcomeBean welcomeBean() {
		return new WelcomeBean();
		
	}
	
	@Bean
	public HelloBean helloBean() {
		HelloBean hello = new HelloBean();
		hello.setName("Satya");
		return hello ;
		
	}

}
