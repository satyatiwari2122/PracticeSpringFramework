package com.satya.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.satya.beans.HelloBean;
import com.satya.beans.WelcomeBean;
import com.satya.config.AppConfig;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		WelcomeBean welBean1 = (WelcomeBean) context.getBean("welcomeBean");
		System.out.println(welBean1.getWelcomeMessage());
		WelcomeBean welBean2 = (WelcomeBean) context.getBean(WelcomeBean.class);
		System.out.println(welBean2.getWelcomeMessage());
		
		HelloBean helloBean = (HelloBean) context.getBean("helloBean");
		System.out.println(helloBean.helloGreetBean());

	}

}
