package com.bharath.spring.springcore1.properties;

import java.util.Properties;

public class CountariesAndLanguages {
	private Properties countryandlangs;

	public Properties getCountryandlangs() {
		return countryandlangs;
	}

	public void setCountryandlangs(Properties countryandlangs) {
		this.countryandlangs = countryandlangs;
	}

	@Override
	public String toString() {
		return "CountariesAndLanguages [countryandlangs=" + countryandlangs + "]";
	}
	

}
