package com.bharath.spring.springcore1.assignment;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"com/bharath/spring/springcore1/assignment/config.xml");
		ShoppingCart cart = (ShoppingCart) context.getBean("student");
		System.out.println("student Score is : "+ cart);

	}

}
