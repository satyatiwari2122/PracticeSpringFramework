package com.satya.spring.springcore1.property.placeholder;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("com/satya/spring/springcore1/property/placeholder/config.xml");
		MyDAO myDAO= (MyDAO) context.getBean("myDAO");
		System.out.println(myDAO);
		WSClient wsClient =(WSClient)context.getBean("wsClient");
		System.out.println(wsClient);
	}

}
