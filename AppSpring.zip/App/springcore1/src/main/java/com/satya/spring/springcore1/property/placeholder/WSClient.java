package com.satya.spring.springcore1.property.placeholder;

public class WSClient {
   private String userName;
   private String passWord;
   private String url;
public WSClient(String userName, String passWord, String url) {
	super();
	this.userName = userName;
	this.passWord = passWord;
	this.url = url;
}
@Override
public String toString() {
	return "WSClient [userName=" + userName + ", passWord=" + passWord + ", url=" + url + "]";
}
   
}
