package com.satya.spring.springcore1.dependencycheck;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// ApplicationContext context = new ClassPathXmlApplicationContext(
		// "com/bharath/spring/springcore1/lc/xmlconfiguration/config.xml");
		AbstractApplicationContext context = new ClassPathXmlApplicationContext(
				"com/satya/spring/springcore1/dependencycheck/config.xml");
		Prescription prescription = (Prescription) context.getBean("prescription");
		System.out.println(prescription);
		context.registerShutdownHook();

	}

}
