package com.satya.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.satya.beans.Employee;
public class Test {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Resource resource = new ClassPathResource("/com/satya/resource/applicationContext.xml");
		BeanFactory factory = new XmlBeanFactory(resource);
		Employee emp = (Employee) factory.getBean("emp");
		emp.getEmployeeDetails();
	}

}
