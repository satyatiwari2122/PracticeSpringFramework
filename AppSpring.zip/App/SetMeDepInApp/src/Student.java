import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class Student {
  private String  sid;
  private String  sname;
  private List <String> squal;
  private Set <String> scourses;
  private Map<String, String> scourse_and_faculty;
  private Properties scourses_and_Cost;
  private Address sadd;
public String getSid() {
	return sid;
}
public void setSid(String sid) {
	this.sid = sid;
}
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public Address getSadd() {
	return sadd;
}
public void setSadd(Address sadd) {
	this.sadd = sadd;
}

public List<String> getSqual() {
	return squal;
}
public void setSqual(List<String> squal) {
	this.squal = squal;
}

public Set<String> getScourses() {
	return scourses;
}
public void setScourses(Set<String> scourses) {
	this.scourses = scourses;
}

public Map<String, String> getScourse_and_faculty() {
	return scourse_and_faculty;
}
public void setScourse_and_faculty(Map<String, String> scourse_and_faculty) {
	this.scourse_and_faculty = scourse_and_faculty;
}

public Properties getScourses_and_Cost() {
	return scourses_and_Cost;
}
public void setScourses_and_Cost(Properties scourses_and_Cost) {
	this.scourses_and_Cost = scourses_and_Cost;
}
public void studentDetails() {
	System.out.println("Student Name : "+ sname);
	System.out.println("Student Id : "+ sid);
	System.out.print("Student Degree : ");
	for(String s:squal) {
		System.out.print(s+" ");
	}
	System.out.println();
	System.out.print("Student Course and Faculty : " +scourse_and_faculty);
	System.out.println();
	System.out.print("Student Course and Cost : " +scourses_and_Cost);
	System.out.println();
	System.out.print("Student Courses : ");
	for(String s:scourses) {
		System.out.print(s+" ");
	}
	System.out.println();
	System.out.println("Student Address : "+sadd.getCity());
}
  
}
