import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.test.annotation.Repeat;

public class Employee {
	private String eid;
	private String ename;
	private float esal;
	private String eaddr;
	private Account acc;
	public String getEid() {
		return eid;
	}
	public void setEid(String eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public float getEsal() {
		return esal;
	}
	public void setEsal(float esal) {
		this.esal = esal;
	}
	public String getEaddr() {
		return eaddr;
	}
	public void setEaddr(String eaddr) {
		this.eaddr = eaddr;
	}
	public Account getAcc() {
		return acc;
	}
	@Required
	//@Autowired(required=true)
	@Qualifier("account1")
	public void setAcc(Account acc) {
		this.acc = acc;
	}
	
	public void getEmployeeDetails() {
		System.out.println("Emplyee Id : "+ eid );
		System.out.println("Emplyee Name : "+ ename );
		System.out.println("Emplyee Sal : "+ esal );
		System.out.println("Emplyee Address : "+ eaddr );
		System.out.println("Emplyee Account details : " );
		System.out.println("Account No  : "+ acc.getAccNo());
		System.out.println("Account Name : "+ acc.getAccName() );
		System.out.println("Account Type : "+ acc.getAccType() );
		System.out.println("Account Balance : "+ acc.getBalance() );
	}
}
