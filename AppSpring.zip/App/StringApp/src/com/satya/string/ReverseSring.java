package com.satya.string;

public class ReverseSring {

	public static void main(String[] args) {
		// by using for loop
		String str= "Hello World";
		String rev =""; 
		int n= str.length();
		
		for (int i = n-1; i >=0; i--) {
			char ch = str.charAt(i);
			rev= rev+ch;
		}
		System.out.println(rev);
		
		// by using string buffer
		StringBuffer sf = new StringBuffer(str);
		System.out.println(sf.reverse());
	}

}
