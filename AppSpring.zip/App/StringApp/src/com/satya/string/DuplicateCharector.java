package com.satya.string;

import java.util.LinkedHashSet;
import java.util.Set;

public class DuplicateCharector {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str= "programming";
		
		// by using java 8 stream api;
		
		StringBuilder sb1= new StringBuilder();
		str.chars().distinct().forEach(c->sb1.append((char)c));
		System.out.println(sb1);
		
		// by using indexOf()
		String str1= new String();
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			int index = str.indexOf(ch, i+1);
			if (index == -1) {
				str1= str1+ch;
			}else {
				System.out.println("duplicate Character is : "+ch);
			}
		}
		System.out.println(str1);
		
		// by using charArray()
		String sb2 =new String();
		char [] arr = str.toCharArray();
		for (int i = 0; i < arr.length; i++) {
			boolean repeated = false;
			for (int j = i+1; j < arr.length; j++) {
				if(arr[i] == arr[j]) {
					repeated = true;
					break;
				}
			}
			if(!repeated) {
				sb2 = sb2 + arr[i];
			}
		}
		System.out.println(sb2);
		
		// using set interface
		StringBuilder sb3 = new StringBuilder();
		Set <Character> set = new LinkedHashSet<Character>();
		for (int i = 0; i < str.length(); i++) {
			set.add(str.charAt(i));
		}
		for(Character c: set) {
			sb3.append(c);
		}
		System.out.println(sb3);
		

	}

}
