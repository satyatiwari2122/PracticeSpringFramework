package com.satya.string;

import java.util.Arrays;

public class SortStringCharacter {

	public static void main(String[] args) {
		// without using sort method
		String str  = "rock";
		char [] arr= str.toCharArray();
		char temp;
		for (int i = 0; i < arr.length; i++) {
			for (int j = i+1; j < arr.length; j++) {
				if(arr[i] > arr[j]) {
					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
		System.out.println(new String(arr));
		// by using sort();
		char [] array = str.toCharArray();
		Arrays.sort(array);
		System.out.println(new String(array));
		

	}

}
