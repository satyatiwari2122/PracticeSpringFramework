package com.satya.string;

public class RemoveSpace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "  ja r   t    u       ";
		String trimStr = str.trim();
		//System.out.println(trimStr);
		System.out.println(str.replaceAll("\\s", ""));

	}

}
