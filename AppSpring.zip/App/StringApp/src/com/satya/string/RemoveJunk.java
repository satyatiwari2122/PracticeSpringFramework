package com.satya.string;

public class RemoveJunk {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s= "早上好Helo123_";
		System.out.println(s.replaceAll("[^a-zA-Z0-9_]", ""));

	}

}
