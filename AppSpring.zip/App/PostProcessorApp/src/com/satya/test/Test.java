package com.satya.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.satya.beans.Account;
import com.satya.beans.Course;

public class Test {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("/com/satya/resources/ApplicationContext.xml");
		Account account = (Account) context.getBean("accountBean");
		account.getAccountDetails();
		System.out.println();
		Course course = (Course) context.getBean("courseBean");
		course.getCourseDetails();
		
		
	}

}
