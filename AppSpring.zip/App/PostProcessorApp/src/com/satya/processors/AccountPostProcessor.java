package com.satya.processors;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

import com.satya.beans.Account;
import com.satya.beans.Course;
public class AccountPostProcessor implements BeanPostProcessor {

	@Override
	public Object postProcessAfterInitialization(Object bean, String name) throws BeansException {
		Account acc = (Account) bean;
		if (acc.getAccType().equals("null")) {
			acc.setAccType("Savings");	
		}
		// TODO Auto-generated method stub
		return acc;
	}

	@Override
	public Object postProcessBeforeInitialization(Object bean, String name) throws BeansException {
		// TODO Auto-generated method stub
		Account acc = (Account) bean;
		String email = acc.getAccHolderEmail();
		
		if (!email.contains("@")) {
			email = email + "@gmail.com";
			acc.setAccHolderEmail(email);
		}
		String mobile = acc.getAccHolderMobile();
		if(!mobile.contains("-")) {
			mobile ="91-" + mobile;
			acc.setAccHolderMobile(mobile);
		}
		return acc;
	}

}
