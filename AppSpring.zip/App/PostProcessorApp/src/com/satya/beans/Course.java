package com.satya.beans;

public class Course {
	private String  cname;
	private String cid;
	private int cfees;
	public Course(String cname, String cid, int cfees) {
		this.cname = cname;
		this.cid = cid;
		this.cfees = cfees;
	}
	
	public void getCourseDetails() {
		System.out.println("Course details are Following : ");
		System.out.println("-----------------------------------");
		System.out.println("Course name is  :           "+cname);
		System.out.println("Course id is  :           "+cid);
		System.out.println("Course Fees is  :           "+cfees);
	}

}
