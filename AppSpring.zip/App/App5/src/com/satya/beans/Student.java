package com.satya.beans;

public class Student {
	private int sid;
	private String sname;
	private String saddr;
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSaddr() {
		return saddr;
	}
	public void setSaddr(String saddr) {
		this.saddr = saddr;
	}
	
	public void getStudentDetails() {
		System.out.println("Student details are : ..........");
		System.out.println("----------------------------------");
		System.out.println("Student id  : "+ sid);
		System.out.println("Student id  : "+ sname);
		System.out.println("Student id  : "+ saddr);
	}
	
}
