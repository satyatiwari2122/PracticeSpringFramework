package com.satya.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.satya.beans.Student;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("/com/satya/resources/ApplicationContext.xml");
		Student stu = (Student) context.getBean("stuBean");
		stu.getStudentDetails();

	}

}
