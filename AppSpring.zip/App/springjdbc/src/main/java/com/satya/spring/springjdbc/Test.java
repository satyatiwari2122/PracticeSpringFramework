package com.satya.spring.springjdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("com/satya/spring/springjdbc/config.xml");
		JdbcTemplate jdbcTemplate = (JdbcTemplate) context.getBean("jdbcTemplate");
		String sql = " INSERT INTO employee (id, firstname, lastname) VALUES(?,?,?) ";
		int result = jdbcTemplate.update(sql, new Integer(1) , "Satya", "Tiwari");
		System.out.println("Nuber records are inserted : " +result);
	}

}
