package com.satya.spring.springmvcorm.user.dao;

import com.satya.spring.springmvcorm.user.entity.User;

public interface UserDao {
	int create(User user) ;

}
