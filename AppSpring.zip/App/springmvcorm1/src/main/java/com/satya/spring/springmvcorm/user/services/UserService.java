package com.satya.spring.springmvcorm.user.services;

import com.satya.spring.springmvcorm.user.entity.User;

public interface UserService {
	int save(User user);

}
