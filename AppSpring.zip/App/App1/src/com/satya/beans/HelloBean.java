package com.satya.beans;

public class HelloBean {
	public String sayHello() {
		return "Hello";
	}
}
