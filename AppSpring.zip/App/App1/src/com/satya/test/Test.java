package com.satya.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.satya.beans.HelloBean;

public class Test {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("/com/satya/resources/applicationContext.xml");
        HelloBean hello = (HelloBean) context.getBean("helloBean");
        System.out.println(hello.sayHello());
	}

}
