import java.util.*;
public class Hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("Hello");
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter user id : ");
		int id = sc.nextInt();
		//System.out.println();
		System.out.print("Enter user name : ");
		String name = sc.next();
		System.out.println("User id is : "+ id);
		System.out.println("User name is : "+ name);
		sc.close();

	}

}
