package com.satya.beans;

public class HelloBean {
	private String name;
	private String message;
	
	public String getHello() {
		return name+" "+" "+ message;
	}
	
	public void init() {
		System.out.println("This is HelloBean init");
		name = "Satya";
		message = "Hello Welcome to delhi";
	}
	public void destroy() {
		System.out.println("HelloBean destoyed");
	}

}
