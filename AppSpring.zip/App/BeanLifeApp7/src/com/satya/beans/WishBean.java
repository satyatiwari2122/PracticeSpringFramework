package com.satya.beans;

public class WishBean {
	private String name;
	private String message;
	
	public String getWish() {
		return name+" "+" "+ message;
	}
	
	public void init() {
		System.out.println("This is WishBean init");
		name = "Satya";
		message = "Verry Very Good Morning !";
	}
	public void destroy() {
		System.out.println("HelloBean destoyed");
	}
}
