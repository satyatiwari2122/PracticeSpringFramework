package com.satya.beans;

public class HiBean {
	private String name;
	private String message;
	
	public String getHi() {
		return name+" "+" "+ message;
	}
	
	public void init() {
		System.out.println("This is HiBean init");
		name = "Satya";
		message = "Hi How was your journy";
	}
	public void destroy() {
		System.out.println("HelloBean destoyed");
	}
}
