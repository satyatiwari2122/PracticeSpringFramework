package com.satya.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.satya.beans.HelloBean;
import com.satya.beans.HiBean;
import com.satya.beans.WishBean;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("/com/satya/resources/applicationContext.xml");
		HelloBean hb = (HelloBean) context.getBean("helloBean");
		System.out.println(hb.getHello());
		
		WishBean wb = (WishBean) context.getBean("wishBean");
		System.out.println(wb.getWish());
		
		HiBean hib = (HiBean) context.getBean("hiBean");
		System.out.println(hib.getHi());
		
		context.registerShutdownHook();

	}

}
